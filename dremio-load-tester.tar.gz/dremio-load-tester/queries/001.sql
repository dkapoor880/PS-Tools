select * from JobAnalysis.Application.Top20DataSetsQueried
