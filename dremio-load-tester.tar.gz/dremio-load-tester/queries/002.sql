select * from staging."auction_won_vw"
