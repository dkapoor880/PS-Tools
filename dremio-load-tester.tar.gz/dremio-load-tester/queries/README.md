This folder is used to store the queries that are executed by the Dremio Load Tester

