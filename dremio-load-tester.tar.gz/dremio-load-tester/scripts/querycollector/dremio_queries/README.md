This directory is used to pre-process queries.json, queries.YYYY-MM-DD.N.json and queries.YYYY-MM-DD.N.json.gz files prior to consumption in Dremio.

