dremio_host=192.168.0.21
dremio_port=9047
vdsdefinition_dir="../../vdsdefinition"
user_name="dremio"
#Assumes local.pwd exists in /home/dremio. Alternatively the password can be entered explicitly in this file
pwd=$(cat ../../../local.pwd) 

# Capture output of script
NOW=$(date +%Y%m%d%H%M%S)
log_file="../../logs/dremio-vdscreator-$NOW.log"

echo "Started run_vdscreator with params:  username="$user_name"  vdsdefinition_dir="$vdsdefinition_dir 2>&1 | tee -a $log_file

java -jar vdscreator-all-1.0.0.jar $dremio_host $dremio_port $user_name $pwd $vdsdefinition_dir | tee -a $log_file

