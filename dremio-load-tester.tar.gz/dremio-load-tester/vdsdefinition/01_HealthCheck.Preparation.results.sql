CREATE OR REPLACE VDS 
HealthCheck.Preparation.results 
AS 
SELECT 
	regexp_extract(queryTextFirstChunk, '--Test-(.*)', 1) AS query_header, 
	'Q' || regexp_extract(split_part("queryTextFirstChunk", ' ', 1), '--Q(.*)', 1) AS jmeterQueryId,
	* 
FROM PSHealthCheck.results