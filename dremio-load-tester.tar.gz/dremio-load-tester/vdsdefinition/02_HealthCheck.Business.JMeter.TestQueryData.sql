CREATE OR REPLACE VDS 
HealthCheck.Business.JMeter.TestQueryData 
AS 
SELECT 
	CAST(split_part(query_header, '|', 1) AS INTEGER) AS testId, 
	to_timestamp(CAST(split_part(query_header, '|', 1) AS INTEGER)) - INTERVAL '7' HOUR AS testStartTime, 
	jmeterQueryId, 
	split_part(query_header, '|', 2) AS testType, 
	split_part(split_part(query_header, '|', 3), '-', 2) AS numExecutors, 
	split_part(split_part(query_header, '|', 4), '-', 2) AS numConcurrentUsers, 
	split_part(split_part(query_header, '|', 5), '-', 2) AS numQPU, 
	split_part(split_part(query_header, '|', 6), '-', 2) AS usersRampTime, 
	split_part(split_part(query_header, '|', 7), '-', 2) AS userId, 
	split_part(split_part(query_header, '|', 8), '-', 2) AS dremioHost,
	split_part(split_part(query_header, '|', 9), '-', 2) AS testDescription, 
	split_part(split_part(query_header, '|', 10), '-', 2) AS queryCounter, 
	finish - "start" AS totalDurationMS, 
	queryId, 
	/*"schema", */
	queryTextFirstChunk as queryText, 
	queryChunkSizeBytes, 
	nrQueryChunks, 
	"start", 
	finish, 
	outcome, 
	username, 
	requestType, 
	queryType, 
	queueName, 
    poolWaitTime, 
	planningTime, 
	enqueuedTime, 
	executionTime, 
	accelerated, 
	parentsList, 
	list_to_delimited_string(reflectionRelationships, '|') AS reflectionRelationships, 
	inputRecords, 
	inputBytes, 
	outputRecords, 
	outputBytes, 
	queryCost, 
	concat(concat(concat('http://', split_part(split_part(query_header, '|', 8), '-', 2)), ':9047/jobs?#'), queryId) AS profileUrl 
FROM 
	HealthCheck.Preparation.results 
WHERE 
	split_part(query_header, '|', 2) IN ('SEQUENTIAL', 'CONCURRENCY') 
	AND queryType = 'JDBC'