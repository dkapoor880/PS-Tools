CREATE OR REPLACE VDS 
HealthCheck.Application.JMeter.LoadTestResultsSummary 
AS 
  SELECT 
    testId, 
    jmeterQueryId,  
	numExecutors, 
	numConcurrentUsers,  
	numQPU, 
    count(*) cnt, 
	queueName, 
	round(avg(queryCost)) AS avgQueryCost, 
    round(avg(poolWaitTime) / 1000.0, 3) as avgPoolWaitTimeSec, 
    round(avg(planningTime) / 1000.0, 3) as avgPlanningTimeSec,
	round(avg(enqueuedTime)/1000.0, 3)  as avgEnqueuedTimeSec, 
    round(avg(totalDurationMS)/1000.0, 3)  as avgTotalDurationSec, 
    round(stddev(totalDurationMS)/1000.0, 3) as stdDevDurationSec, 
    round(stddev(totalDurationMS) / avg(totalDurationMS) * 100) as coeffVarPercent, 
    round(min(totalDurationMS)/1000.0, 3) as minTotalDurationSec, 
    round(max(totalDurationMS)/1000.0, 3) as maxTotalDurationSec 
  FROM 
    HealthCheck.Application.JMeter.LoadTestResults 
  WHERE 
    outcome='COMPLETED' 
  GROUP BY 
    testId, 
    jmeterQueryId, 
	numExecutors, 
	numConcurrentUsers,  
	numQPU, 
	queueName 
  Order by  
    testId, 
    coeffVarPercent DESC
