CREATE OR REPLACE VDS 
	HealthCheck.Application.JMeter.LoadTestDescription 
AS 
SELECT 
	originalTestId, 
	testId, 
	numExecutors, 
	numConcurrentUsers, 
	numQPU,
	dremioHost,
	testDescription, 
	TO_TIMESTAMP(MIN(queryStartTime), 'YYYY-MM-DD HH24:MI:SS', 1) AS testStartTime, 
	TO_TIMESTAMP(MAX(queryFinishTime), 'YYYY-MM-DD HH24:MI:SS', 1) AS testFinishTime, 
	TIMESTAMPDIFF(SECOND, 
        TO_TIMESTAMP(MIN(queryStartTime), 'YYYY-MM-DD HH24:MI:SS', 1), 
        TO_TIMESTAMP(MAX(queryFinishTime), 'YYYY-MM-DD HH24:MI:SS', 1)) AS testDurationSecs 
FROM HealthCheck.Application.JMeter.LoadTestResults 
GROUP BY 
	originalTestId, 
	testId, 
	numExecutors, 
	numConcurrentUsers, 
	numQPU,
	dremioHost,
	testDescription	
/*HAVING COUNT("testId") > 10*/ 
ORDER BY 
	originalTestId ASC
