CREATE OR REPLACE VDS 
HealthCheck.Application.JMeter.LoadTestQueueUsage 
AS 
SELECT
    originalTestId,
    testId, 
    queueName, 
    numQueriesPerQueue, 
    (cast(numQueriesPerQueue as float) / 
     cast(sum (numQueriesPerQueue) over (partition by testId) as float)) * 100 as queueUsagePct 
FROM
    (SELECT 
        originalTestId,
        testId, 
        queueName, 
        count(queueName) as numQueriesPerQueue 
    FROM HealthCheck.Application.JMeter.LoadTestResults
    GROUP BY originalTestId, testId, queueName) a 
ORDER BY 
    a.originalTestId ASC, 
    a.queueName ASC