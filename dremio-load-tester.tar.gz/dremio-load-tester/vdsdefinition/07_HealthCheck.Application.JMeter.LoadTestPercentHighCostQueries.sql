CREATE OR REPLACE VDS 
HealthCheck.Application.JMeter.LoadTestPercentHighCostQueries 
AS 
SELECT 
    originalTestId, 
    testId, 
    outcome, 
    count(testId) as testCount, 
    sum(case when queueName = 'High Cost User Queries' then 1 else 0 end) as highCostCount, 
    sum(case when queueName = 'High Cost User Queries' then 1 else 0 end) / cast(count(testId) as float) * 100 as pctHighCost 
FROM HealthCheck.Application.JMeter.LoadTestResults 
GROUP BY originalTestId, testId, outcome 
HAVING outcome = 'COMPLETED' 
ORDER BY originalTestId ASC