CREATE OR REPLACE VDS 
HealthCheck.Application.JMeter.LoadTestPercentAccelerated 
AS 
SELECT 
    originalTestId, 
    testId, 
    outcome, 
    count(testId) as testCount, 
    sum(case when accelerated = 'true' then 1 else 0 end) as acceleratedCount, 
    sum(case when accelerated = 'true' then 1 else 0 end) / cast(count(testId) as float) * 100 as pctAccelerated 
FROM HealthCheck.Application.JMeter.LoadTestResults 
GROUP BY originalTestId, testId, outcome 
HAVING outcome = 'COMPLETED' 
ORDER BY originalTestId asc