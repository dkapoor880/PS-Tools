CREATE OR REPLACE VDS 
HealthCheck.Application.JMeter.LoadTestAvgQueueEnqueuedTime 
AS 
SELECT testId, queueName, AVG(enqueuedTime) avgEnqueuedTimeMS 
FROM HealthCheck.Application.JMeter.LoadTestResults 
WHERE queueName != '' 
GROUP BY testId, queueName 
ORDER BY testId ASC, queueName DESC 