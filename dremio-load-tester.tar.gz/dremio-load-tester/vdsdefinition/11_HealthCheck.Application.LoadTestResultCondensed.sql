CREATE OR REPLACE VDS
HealthCheck.Application.LoadTestResultCondensed
AS
SELECT "CONCAT"("LPAD"(DENSE_RANK() OVER (ORDER BY "testId"), 3, '0'), '_E', "numExecutors", 'C', "numConcurrentUsers", 'Q', "numQPU") AS "testId", "jmeterQueryId", "queryCounter", "TO_TIMESTAMP"("start" / 1000.0) AS "queryStartTime", "TO_TIMESTAMP"("finish" / 1000.0) AS "queryFinishTime", "totalDurationMS", 
CASE 
WHEN "totalDurationMS" > 0 AND "totalDurationMS" <= 5000 THEN '5s' 
WHEN "totalDurationMS" > 5000 AND "totalDurationMS" <= 10000 THEN '5-10s' 
WHEN "totalDurationMS" > 10000 AND "totalDurationMS" <= 15000 THEN '10-15s' 
WHEN "totalDurationMS" > 15000 AND "totalDurationMS" <= 20000 THEN '15-20s' 
WHEN "totalDurationMS" > 20000 AND "totalDurationMS" <= 25000 THEN '20-25s' 
WHEN "totalDurationMS" > 25000 AND "totalDurationMS" <= 30000 THEN '25-30s' 
WHEN "totalDurationMS" > 30000 AND "totalDurationMS" <= 35000 THEN '30-35s' 
WHEN "totalDurationMS" > 35000 AND "totalDurationMS" <= 40000 THEN '35-40s' 
WHEN "totalDurationMS" > 40000 AND "totalDurationMS" <= 45000 THEN '40-45s' 
WHEN "totalDurationMS" > 45000 AND "totalDurationMS" <= 50000 THEN '45-50s' 
WHEN "totalDurationMS" > 50000 AND "totalDurationMS" <= 55000 THEN '50-55s' 
WHEN "totalDurationMS" > 55000 AND "totalDurationMS" <= 60000 THEN '55-60s' 
ELSE '>60' END AS "DurationQtile", 
CASE 
WHEN "totalDurationMS" > 0 AND "totalDurationMS" <= 5000 THEN 1 
WHEN "totalDurationMS" > 5000 AND "totalDurationMS" <= 10000 THEN 2 
WHEN "totalDurationMS" > 10000 AND "totalDurationMS" <= 15000 THEN 3 
WHEN "totalDurationMS" > 15000 AND "totalDurationMS" <= 20000 THEN 4
WHEN "totalDurationMS" > 20000 AND "totalDurationMS" <= 25000 THEN 5 
WHEN "totalDurationMS" > 25000 AND "totalDurationMS" <= 30000 THEN 6 
WHEN "totalDurationMS" > 30000 AND "totalDurationMS" <= 35000 THEN 7 
WHEN "totalDurationMS" > 35000 AND "totalDurationMS" <= 40000 THEN 8 
WHEN "totalDurationMS" > 40000 AND "totalDurationMS" <= 45000 THEN 9 
WHEN "totalDurationMS" > 45000 AND "totalDurationMS" <= 50000 THEN 10 
WHEN "totalDurationMS" > 50000 AND "totalDurationMS" <= 55000 THEN 11 
WHEN "totalDurationMS" > 55000 AND "totalDurationMS" <= 60000 THEN 12 
ELSE 13 END AS "DurationQtileId", 
"queryId", "start", "finish", "outcome", "username", "queueName", "poolWaitTime", "planningTime", "enqueuedTime", "executionTime", "inputRecords", "inputBytes", "outputRecords", "outputBytes", "queryCost", 
CASE 
WHEN "QueryCost" > 0 AND "QueryCost" <= 100000000 THEN '0-100M' 
WHEN "QueryCost" > 100000000 AND "QueryCost" <= 1000000000 THEN '100M-1B' 
WHEN "QueryCost" > 1000000000 AND "QueryCost" <= 5000000000 THEN '1B-5B' 
WHEN "QueryCost" > 5000000000 AND "QueryCost" <= 10000000000 THEN '5-10B' 
WHEN "QueryCost" > 10000000000 AND "QueryCost" <= 100000000000 THEN '10-100B' 
ELSE '100B-Up' 
END AS "CostBucket", 
CASE 
WHEN "QueryCost" > 0 AND "QueryCost" <= 100000000 THEN 1 
WHEN "QueryCost" > 100000000 AND "QueryCost" <= 1000000000 THEN 2 
WHEN "QueryCost" > 1000000000 AND "QueryCost" <= 5000000000 THEN 3 
WHEN "QueryCost" > 5000000000 AND "QueryCost" <= 10000000000 THEN 4 
WHEN "QueryCost" > 10000000000 AND "QueryCost" <= 100000000000 THEN 5 
ELSE 6 
END 
AS "CostBucketId", 
"testId" AS "originalTestId", "testType", "numConcurrentUsers", "numQPU", "usersRampTime", "userId", "testStartTime", "SUBSTR"("LTRIM"("SPLIT_PART"("queryText", '|', 10), 'counter-'), "STRPOS"("LTRIM"("SPLIT_PART"("queryText", '|', 10), 'counter-'), 'SELECT')) AS "queryText"
FROM "HealthCheck"."Business"."TestQueryData"
ORDER BY "testId", "start"

