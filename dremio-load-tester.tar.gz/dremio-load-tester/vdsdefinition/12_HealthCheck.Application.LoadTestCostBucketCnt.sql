CREATE OR REPLACE VDS 
HealthCheck.Application.LoadTestCostBucketCnt
AS 
SELECT testId,CostBucket,count(*) as BucketCnt 
FROM HealthCheck.Application.LoadTestResultCondensed
group by testId,CostBucket,CostBucketId
order by testId,CostBucketId
