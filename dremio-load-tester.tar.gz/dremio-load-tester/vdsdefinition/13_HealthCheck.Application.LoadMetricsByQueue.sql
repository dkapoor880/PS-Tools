CREATE OR REPLACE VDS 
HealthCheck.Application.LoadTestMetricsByQueue
AS 
  SELECT "testId", "queueName", COUNT(*) AS "QueryCnt", MIN("planningTime") AS "MinPlanTimeMS",MAX("planningTime") AS "MaxPlanTimeMS", CAST(ROUND(AVG("planningTime")) as INTEGER) AS "AvgPlanTimeMS"
  ,MIN("executionTime") AS "MinExecTimeMS", MAX("executionTime") AS "MaxExecTimeMS", CAST(ROUND(AVG("executionTime")) as INTEGER) AS "AvgExecTimeMS"
  ,MIN("totalDurationMS") AS "MinDurTimeMS", MAX("totalDurationMS") AS "MaxDurTimeMS", CAST(ROUND(AVG("totalDurationMS")) as INTEGER) AS "AvgDurTimeMS"
  FROM "HealthCheck"."Application"."LoadTestResults"
  WHERE "queueName" <> ''
  GROUP BY "testId", "queueName"
  ORDER BY "testId", "queueName" DESC
