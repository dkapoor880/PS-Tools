CREATE OR REPLACE VDS 
HealthCheck.Application.LoadDurationQtile
AS 
SELECT "testId", "DurationQtile", COUNT(*) AS "Cnt"
FROM HealthCheck.Application.LoadTestResultCondensed
where queueName <> ''
GROUP BY "testId", "DurationQtile", "DurationQtileId"
ORDER BY "testId", "DurationQtileId"
