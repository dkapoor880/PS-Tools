CREATE OR REPLACE VDS 
HealthCheck.Application.LoadTestByOutcome
AS 
SELECT testId,outcome,count(*) OutcomeCnt
FROM HealthCheck.Application.LoadTestResultCondensed
group by testId,outcome
order by testId,outcome
