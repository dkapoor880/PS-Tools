This folder is used to store the scrubbed queries.json files prior to loading them into S3/HDFS/ADLS/Minio for further analysis in Dremio.

