# Dremio Query Analyzer - VDS Creator
This tool will automatically create the Space, Folders and VDSs required to analyse queries.json files.

## Usage
On the command line, navigate to /path_to_dremio-query-analyzer/scripts/vdscreator.

Open run_vdscreator.sh in a text editor and ensure the following parameters are configured correctly at the top of the script:
dremio_host - Dremio host where the VDS definitions will be created
dremio_port - Dremio web port, defaults to 9047
user_name - username of a Dremio user capable of creating VDSs
pwd - password of the user

Save the file.

Execute the following command:

./run_vdscreator.sh



# Dremio Query Analyzer - Refresh PDS
This tool will automatically refresh the given PDS (full path to PDS in Dremio required) to read in any new files.

## Usage
On the command line, navigate to /path_to_dremio-query-analyzer/scripts/vdscreator.

Open run_refreshpds.sh in a text editor and ensure the following parameters are configured correctly at the top of the script:
dremio_host - Dremio host where the VDS definitions will be created
dremio_port - Dremio web port, defaults to 9047
user_name - username of a Dremio user capable of creating VDSs
pwd - password of the user

Save the file.

Execute the following command:

./run_refreshpds.sh <full_path_to_PDS_to_refresh>