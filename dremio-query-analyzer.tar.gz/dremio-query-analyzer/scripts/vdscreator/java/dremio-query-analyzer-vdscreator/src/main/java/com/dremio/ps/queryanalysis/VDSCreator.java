package com.dremio.ps.queryanalysis;

import java.io.File;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.util.Arrays;
import java.util.List;

class VDSCreator {
	public static void main(String args[]){
		if (args.length < 5) {
			System.err.println("usage : java -jar vdscreator-q-all-1.0.0.jar <host name> <port> <user> <password> <vdsDefinitionDir>");
			System.exit(1);
		}
		
		String ip = args[0]; // IP or host name of Dremio
		String userName = args[2];
		String password = args[3];
		String vdsDefinitionDir = args[4];
		int port = Integer.parseInt(args[1]);
		String[] catalog = {
				"space.QueryAnalysis", 
				"folder.QueryAnalysis.Preparation",
				"folder.QueryAnalysis.Business", 
				"folder.QueryAnalysis.Application"};
			
		String payload = null;
		String response = null;

		try {
			DremioApi dremio = new DremioApi("http://" + ip + ":" + port, userName, password);
			if ("refreshpds".equalsIgnoreCase(vdsDefinitionDir)) {
				// We are using VDSCreator to refresh a PDS - we do this when new files have been added to a source
				String pds = args[5];
				
				dremio.postSQL("ALTER PDS " + pds + " REFRESH METADATA LAZY UPDATE", null);
			} else {
				// Create space and folders from the catalog array
				for (int catIdx = 0; catIdx < catalog.length; catIdx++) {
					String[] entity = catalog[catIdx].split("\\.");
					String entityType = entity[0];
					StringBuffer entityName = new StringBuffer();
					
					// Create the entity name\path array from the entity value
					for (int entIdx = 1; entIdx < entity.length; entIdx++) {
						if (entIdx > 1) {
							entityName.append(",");
						}
						entityName.append("\"" + entity[entIdx]+ "\"");
					}
					
					if ("space".equalsIgnoreCase(entityType)) {
						payload = "{\"entityType\": \"" + entityType + "\",\"name\": " + entityName + "}";
					} else { // assume entityType is folder
						payload = "{\"entityType\": \"" + entityType + "\", \"path\": [" + entityName +"]}";
					}
					
					try {
						response = dremio.postCatalog(payload);
						System.out.println(entityType + " " + entityName.toString().replaceAll(",",  "\\.") + " created. Response: " + response);
					} catch (Exception e) {
						if (e.getMessage().contains("409")) {
							System.out.println(entityType + " " + entityName.toString().replaceAll(",",  "\\.") +  " already exists, continuing");
						} else {
							throw e;
						}
					}
				}
				
				File directory = new File(vdsDefinitionDir);
				
				if (directory.exists()) {
					System.out.println("Directory " + directory.getAbsolutePath() + " exists");
				}
				else {
					throw new Exception("Directory " + directory + " does not exist");
				}
				
				File[] sqlFiles = directory.getCanonicalFile().listFiles();
	
				Arrays.sort(sqlFiles);
	
				for (int i = 0; i < sqlFiles.length; i++) {
					File sqlFile = sqlFiles[i].getCanonicalFile();
					StringBuffer sqlText = new StringBuffer();
					
					if (sqlFile.getName().endsWith(".sql")) {
						System.out.println("Processing SQL file: " + sqlFile.getName());
								
						// Obtain the SQL from the file
						List<String> lines = Files.readAllLines(sqlFile.getCanonicalFile().toPath(), Charset.defaultCharset());
			          	
						for (String line:lines) {
			          		sqlText.append(line);
			        	}
						
						System.out.println("VDS Definition: " + sqlText);
						
						payload = scrubText(sqlText.toString());
						response = dremio.postSQL(payload, null);
						System.out.println("Response: " + response);
					}
				}
			}
		} 
		catch (Exception e) {
			System.out.println("Failed to create VDS Definitions for Load Test Analysis: " + e.getMessage());
		}
		finally{
		}
	}
	
	private static String scrubText(String text) {
		text = text.replaceAll("\n", "");
		text = text.replaceAll("\t", "");
		text = text.replaceAll("\r", "");
		text = text.replaceAll("\\\\", "\\\\\\\\");
		text = text.replaceAll("\"", "\\\\\"");
		return text;
	}
}
