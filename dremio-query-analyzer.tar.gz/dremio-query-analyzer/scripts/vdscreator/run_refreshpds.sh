dremio_host=192.168.0.21
dremio_port=9047
user_name="dremio"
#Assumes local.pwd exists in /home/dremio. Alternatively the password can be entered explicitly in this file
pwd=$(cat ../../../local.pwd) 
queries_json_pds=$1

# Capture output of script
NOW=$(date +%Y%m%d%H%M%S)
log_file="../../logs/dremio-refreshpds-$NOW.log"

echo "Started run_refreshpds with params:  username="$user_name"  queries_json_pds="$queries_json_pds 2>&1 | tee -a $log_file

java -jar vdscreator-q-all-1.0.0.jar $dremio_host $dremio_port $user_name $pwd refreshpds "$queries_json_pds" | tee -a $log_file

