CREATE OR REPLACE VDS 
QueryAnalysis.Preparation.chunks 
AS 
SELECT 
	* 
FROM QueriesJson.chunks