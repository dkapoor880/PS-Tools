CREATE OR REPLACE VDS 
QueryAnalysis.Preparation.errorchunks 
AS 
SELECT 
	* 
FROM QueriesJson.errorchunks