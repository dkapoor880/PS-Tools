CREATE OR REPLACE VDS 
QueryAnalysis.Preparation.errormessages 
AS 
SELECT 
	* 
FROM QueriesJson.errormessages