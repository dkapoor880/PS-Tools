CREATE OR REPLACE VDS 
QueryAnalysis.Preparation.results 
AS 
SELECT 
	*, 
    "finish" - "start" AS "totalDurationMS"	
FROM QueriesJson.results