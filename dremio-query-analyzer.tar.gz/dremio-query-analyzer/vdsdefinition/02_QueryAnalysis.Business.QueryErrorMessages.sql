CREATE OR REPLACE VDS 
QueryAnalysis.Business.QueryErrorMessages 
AS 
SELECT 
    * 
FROM QueryAnalysis.Preparation.errormessages
