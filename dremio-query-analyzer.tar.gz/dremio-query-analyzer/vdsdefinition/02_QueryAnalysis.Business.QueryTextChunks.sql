CREATE OR REPLACE VDS 
QueryAnalysis.Business.QueryTextChunks 
AS 
SELECT 
    * 
FROM QueryAnalysis.Preparation.chunks
