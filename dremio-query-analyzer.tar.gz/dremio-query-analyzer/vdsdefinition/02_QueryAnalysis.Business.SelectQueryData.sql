CREATE OR REPLACE VDS 
QueryAnalysis.Business.SelectQueryData 
AS 
SELECT 
    queryId, 
    queryTextFirstChunk as queryText, 
	queryChunkSizeBytes, 
	nrQueryChunks, 
    TO_TIMESTAMP("start"/1000.0) as startTime, 
    TO_TIMESTAMP("finish"/1000.0) as finishTime, 
    cast(totalDurationMS/60000.000 as decimal(10,3)) as totalDurationMinutes, 
    cast(totalDurationMS/1000.000 as decimal(10,3)) as totalDurationSeconds, 
    "totalDurationMS", 
    outcome, 
    username, 
    requestType, 
    queryType, 
    parentsList, 
    queueName, 
    poolWaitTime, 
    planningTime, 
    enqueuedTime, 
    executionTime, 
    accelerated, 
    inputRecords, 
    inputBytes, 
    outputRecords, 
    outputBytes, 
    queryCost, 
    "concat"('http://<DREMIO_HOST>:9047/jobs?#', "queryId") AS "profileUrl" 
FROM QueryAnalysis.Preparation.results AS results 
-- We only want select statements 
WHERE UPPER(regexp_extract("queryText",'/(?i)SELECT|select(.*)[\s\S]+$',0)) LIKE 'SELECT%'
