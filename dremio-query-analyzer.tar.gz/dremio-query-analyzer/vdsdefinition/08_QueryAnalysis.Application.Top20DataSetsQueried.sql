CREATE OR REPLACE VDS 
QueryAnalysis.Application.Top20DataSetsQueried   
AS 
SELECT 
    list_to_delimited_string(nested_0.parentsList.datasetPathList, '.') AS dataSet, 
    nested_0.parentsList.type AS dataSetType, 
    count(*) AS countTimesQueried 
FROM ( 
    SELECT flatten(parentsList) as parentsList  
    FROM QueryAnalysis.Business.SelectQueryData 
    WHERE parentsList IS NOT NULL 
    AND requestType = 'RUN_SQL' 
     ) nested_0 
GROUP BY dataSet, dataSetType 
ORDER BY countTimesQueried DESC 
LIMIT 20