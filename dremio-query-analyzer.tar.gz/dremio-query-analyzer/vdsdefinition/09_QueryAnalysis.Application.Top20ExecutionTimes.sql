CREATE OR REPLACE VDS 
QueryAnalysis.Application.Top20ExecutionTimes  
AS 
SELECT * FROM QueryAnalysis.Business.SelectQueryData 
ORDER BY executionTime DESC 
LIMIT 20