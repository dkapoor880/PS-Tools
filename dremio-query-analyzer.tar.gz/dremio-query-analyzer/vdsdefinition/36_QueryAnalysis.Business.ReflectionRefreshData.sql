create or replace VDS QueryAnalysis.Business.ReflectionRefreshData AS
SELECT *
FROM (SELECT "queryId", "queryTextFirstChunk" AS "queryText", "queryChunkSizeBytes", "nrQueryChunks", "TO_TIMESTAMP"("start" / 1000.0) AS "startTime", CAST("TO_TIMESTAMP"("start" / 1000.0) AS DATE) AS "startDate", "TO_TIMESTAMP"("finish" / 1000.0) AS "finishTime", CAST("totalDurationMS" / 60000.000 AS DECIMAL(10, 3)) AS "totalDurationMinutes", CAST("totalDurationMS" / 1000.000 AS DECIMAL(10, 3)) AS "totalDurationSeconds", "totalDurationMS", ROW_NUMBER() OVER (ORDER BY "totalDurationMS" DESC) AS "rownumByTotalDurationMS", "outcome", "username", "requestType", "queryType", "parentsList", "queueName", "poolWaitTime", "planningTime", "enqueuedTime", "executionTime", "accelerated", "inputRecords", "inputBytes", "outputRecords", "outputBytes", "queryCost", "outcomereason", "CONCAT"('http://<DREMIO_HOST>:9047/jobs?#', "queryId") AS "profileUrl"
FROM "QueryAnalysis"."Preparation"."results" AS "results"
WHERE UPPER("queryTextFirstChunk") LIKE '%REFLECTION%') AS "t"
WHERE "rownumByTotalDurationMS" > 0
