create or replace VDS QueryAnalysis.Reflections.FailedReflectionRefreshByDate AS
SELECT "TO_DATE"("startTime") AS "queryStartDate", COUNT(*) AS "failedQueries"
FROM "QueryAnalysis"."Business"."ReflectionRefreshData"
WHERE "OUTCOME" = 'FAILED'
GROUP BY "username", "queryStartDate"
ORDER BY "queryStartDate" DESC, "failedQueries" DESC
