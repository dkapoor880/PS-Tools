create or replace VDS QueryAnalysis.Reflections.FailedReflectionRefreshReason AS
SELECT "outcomeReason", queueName, COUNT(*) AS "failedQueries"
FROM "QueryAnalysis"."Business"."ReflectionRefreshData"
WHERE "OUTCOME" = 'FAILED'
GROUP BY "outcomeReason", queueName
ORDER BY "failedQueries" DESC , queueName
